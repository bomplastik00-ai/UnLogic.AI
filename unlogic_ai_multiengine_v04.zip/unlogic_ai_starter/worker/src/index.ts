export interface Env {
  PROVIDERS_JSON?: string;
  APP_ORIGINS?: string;
  ALLOW_ADULT_MODE?: string;
}
type Provider = {
  label: string; type?: "openai-compatible" | "fal"; baseUrl?: string; apiKey: string;
  model?: string; modelId?: string; endpoint?: string; sizeParam?: boolean;
  responseFormat?: string; adultAllowed?: boolean; capabilities?: string[];
};
const reply=(data:unknown,status=200,headers:Record<string,string>={})=>new Response(JSON.stringify(data),{status,headers:{"Content-Type":"application/json; charset=utf-8",...headers}});
function origins(env:Env){return (env.APP_ORIGINS||"").split(",").map(x=>x.trim()).filter(Boolean)}
function cors(request:Request,env:Env){
 const origin=request.headers.get("Origin")||""; const allowed=origins(env).includes(origin);
 const h:Record<string,string>={"Vary":"Origin","Access-Control-Allow-Methods":"GET, POST, OPTIONS","Access-Control-Allow-Headers":"Content-Type"};
 if(allowed) h["Access-Control-Allow-Origin"]=origin;
 return {headers:h,allowed,origin};
}
function readProviders(env:Env):Record<string,Provider>{
 if(!env.PROVIDERS_JSON) return {};
 try { const parsed=JSON.parse(env.PROVIDERS_JSON); return parsed && typeof parsed==="object" && !Array.isArray(parsed) ? parsed : {}; } catch { return {}; }
}
function validFalModelId(id:string){return id.split("/").length>=2 && id.split("/").length<=5 && id.split("/").every(x=>/^[a-zA-Z0-9._-]+$/.test(x));}
function imageFromResult(parsed:any){
 const item=parsed?.images?.[0] || parsed?.data?.[0] || parsed?.output?.images?.[0];
 if(item?.url) return {imageUrl:item.url};
 if(item?.b64_json) return {b64_json:item.b64_json};
 return null;
}
export default {
 async fetch(request:Request,env:Env):Promise<Response>{
  const url=new URL(request.url); const c=cors(request,env);
  if(request.method==="OPTIONS") return new Response(null,{status:c.allowed?204:403,headers:c.headers});
  if(c.origin && !c.allowed) return reply({error:"Origin not allowed. Add the exact app origin to APP_ORIGINS."},403,c.headers);
  if(url.pathname==="/api/health" && request.method==="GET") {
   const configured=Object.entries(readProviders(env)).filter(([,p])=>!!p.apiKey).map(([id,p])=>({id,label:p.label||id,type:p.type||"openai-compatible",capabilities:p.capabilities||["text-to-image"]}));
   return reply({ok:true,app:"unlogic.ai",stage:"multi-engine-gateway-v0.4",configuredProviders:configured.length,providers:configured},200,c.headers);
  }
  const providers=readProviders(env);
  if(url.pathname==="/api/providers" && request.method==="GET"){
   const safe=Object.entries(providers).map(([id,p])=>({id,label:p.label||id,type:p.type||"openai-compatible",capabilities:p.capabilities||["text-to-image"],adultAllowed:p.adultAllowed===true,ready:!!p.apiKey}));
   return reply({providers:safe},200,c.headers);
  }
  if(url.pathname==="/api/generate" && request.method==="POST"){
   const length=Number(request.headers.get("Content-Length")||0); if(length>20000) return reply({error:"Request too large"},413,c.headers);
   try{
    const body=await request.json() as {prompt?:string;size?:string;model?:string;providerId?:string;adultMode?:boolean};
    const prompt=(body.prompt||"").trim(); if(!prompt) return reply({error:"Prompt is required"},400,c.headers);
    if(prompt.length>8000) return reply({error:"Prompt too long"},413,c.headers);
    if(body.adultMode && env.ALLOW_ADULT_MODE!=="true") return reply({error:"Adult mode is disabled until provider permissions and required safeguards are verified."},403,c.headers);
    const id=body.providerId||Object.keys(providers)[0]; const p=id?providers[id]:undefined;
    if(!p || !p.apiKey) return reply({error:"No configured image engine. Configure PROVIDERS_JSON on the backend."},503,c.headers);
    if(body.adultMode && p.adultAllowed!==true) return reply({error:"Selected provider is not explicitly enabled for adult content."},403,c.headers);
    const type=p.type||"openai-compatible";
    if(type==="fal"){
      if(!p.modelId || !validFalModelId(p.modelId)) return reply({error:"Fal provider needs a valid modelId such as fal-ai/z-image/turbo."},500,c.headers);
      const endpoint=`https://queue.fal.run/${p.modelId}`;
      const falBody:Record<string,unknown>={prompt};
      // Z-Image and several fal image endpoints accept image_size; exact model schemas vary.
      if(body.size==="1024x1536") falBody.image_size={width:1024,height:1536};
      else if(body.size==="1536x1024") falBody.image_size={width:1536,height:1024};
      else falBody.image_size={width:1024,height:1024};
      const upstream=await fetch(endpoint,{method:"POST",headers:{Authorization:`Key ${p.apiKey}`,"Content-Type":"application/json"},body:JSON.stringify(falBody),signal:AbortSignal.timeout(30000)});
      if(!upstream.ok) return reply({error:`fal.ai queue returned HTTP ${upstream.status}. Check model schema, account credits and API key.`},502,c.headers);
      const queued:any=await upstream.json();
      if(!queued?.request_id) return reply({error:"fal.ai did not return a request_id."},502,c.headers);
      return reply({job:{providerId:id,requestId:queued.request_id,status:queued.status||"IN_QUEUE",modelId:p.modelId}},202,c.headers);
    }
    if(type!=="openai-compatible") return reply({error:"Unsupported provider adapter type."},400,c.headers);
    if(!p.baseUrl || !p.model) return reply({error:"OpenAI-compatible provider needs baseUrl and model."},500,c.headers);
    const base=new URL(p.baseUrl); if(base.protocol!=="https:" || base.username || base.password) return reply({error:"Provider baseUrl must be HTTPS and must not contain embedded credentials."},500,c.headers);
    const endpoint=new URL(p.endpoint||"/v1/images/generations",base).toString();
    const payload:Record<string,unknown>={model:body.model && body.model!=="default"?body.model:p.model,prompt,n:1};
    if(p.sizeParam!==false) payload.size=body.size||"1024x1024";
    if(p.responseFormat) payload.response_format=p.responseFormat;
    const upstream=await fetch(endpoint,{method:"POST",headers:{Authorization:`Bearer ${p.apiKey}`,"Content-Type":"application/json"},body:JSON.stringify(payload),signal:AbortSignal.timeout(90000)});
    if(!upstream.ok) return reply({error:`Image provider returned HTTP ${upstream.status}. Check its API docs, model, credits and request format.`},502,c.headers);
    const parsed:any=await upstream.json(); const image=imageFromResult(parsed);
    if(!image) return reply({error:"Unknown provider response format. A provider-specific adapter is needed."},502,c.headers);
    return reply({...image,providerId:id},200,c.headers);
   }catch(e){const msg=e instanceof Error && e.name==="TimeoutError"?"Provider request timed out. Try again or use a faster model.":"Request could not be processed. Check request format and backend logs.";return reply({error:msg},400,c.headers)}
  }
  if(url.pathname==="/api/jobs/status" && request.method==="GET"){
   const id=url.searchParams.get("providerId")||""; const requestId=url.searchParams.get("requestId")||""; const p=providers[id];
   if(!p || p.type!=="fal" || !p.modelId || !validFalModelId(p.modelId)) return reply({error:"Unknown fal provider."},404,c.headers);
   if(!/^[a-zA-Z0-9-]+$/.test(requestId)) return reply({error:"Invalid request ID."},400,c.headers);
   try{
    const base=`https://queue.fal.run/${p.modelId}/requests/${requestId}`;
    const sr=await fetch(base+"/status",{headers:{Authorization:`Key ${p.apiKey}`},signal:AbortSignal.timeout(20000)});
    if(!sr.ok) return reply({error:`Could not read job status (HTTP ${sr.status}).`},502,c.headers);
    const state:any=await sr.json();
    if(state.status!=="COMPLETED") return reply({status:state.status||"IN_PROGRESS",queuePosition:state.queue_position},200,c.headers);
    if(state.error || state.error_type) return reply({status:"FAILED",error:"The selected model could not complete this generation."},200,c.headers);
    const rr=await fetch(base,{headers:{Authorization:`Key ${p.apiKey}`},signal:AbortSignal.timeout(30000)});
    if(!rr.ok) return reply({status:"FAILED",error:`Could not retrieve generated output (HTTP ${rr.status}).`},502,c.headers);
    const output:any=await rr.json(); const image=imageFromResult(output);
    if(!image) return reply({status:"FAILED",error:"Model result did not contain a recognized image URL."},502,c.headers);
    return reply({status:"COMPLETED",...image,providerId:id},200,c.headers);
   }catch{return reply({error:"Could not poll generation job. Try again."},502,c.headers)}
  }
  return reply({error:"Not found"},404,c.headers);
 }
};
