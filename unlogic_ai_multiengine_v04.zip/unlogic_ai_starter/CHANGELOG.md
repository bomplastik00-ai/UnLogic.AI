# Changelog

## v0.2 — multi-engine gateway foundation
- Backend berubah daripada satu konfigurasi provider kepada registry `PROVIDERS_JSON`.
- Endpoint `GET /api/providers` memulangkan senarai engine tanpa mendedahkan API key.
- UI memuatkan pilihan engine daripada backend.
- CORS menggunakan senarai origin yang dibenarkan, bukan echo origin sewenang-wenangnya.
- Adult mode kekal OFF secara lalai dan memerlukan flag global serta kelulusan khusus provider.
- Android WebView menggunakan AndroidX WebKit AssetLoader supaya UI dimuatkan melalui origin HTTPS tempatan.
- GitHub Actions disediakan untuk membina APK debug.

## Belum termasuk
- Provider API key atau kredit.
- Adapter sebenar untuk edit, video, effects dan character swap.
- Login, kuota, billing, database, storage kekal dan rate limiting.
- APK yang telah dikompilasi dan diuji pada peranti sebenar.


## v0.3 — asynchronous image provider adapter
- Tambah adapter queue fal.ai (`Authorization: Key ...`) untuk model yang disediakan dalam konfigurasi.
- Tambah endpoint polling `/api/jobs/status` yang mengambil status dan result di server-side.
- UI boleh menunggu job asynchronous dan memaparkan imej selepas siap.
- Provider registry kini boleh menerangkan type dan capabilities.
- Kekalkan OpenAI-compatible adapter sebagai pilihan kedua.

- Tambah `ENGINE_RESEARCH_MS.md` dengan perbandingan awal fal.ai, Hugging Face dan Cloudflare berdasarkan dokumentasi rasmi.

## v0.4 — 2026-11-14
- Added backend health diagnostics and a one-tap engine reload in the UI.
- Health response reports configured provider labels/types/capabilities only; API keys remain private.
- Provider list now exposes readiness without exposing credentials.
- Disabled unfinished module actions clearly instead of letting users submit a request that cannot work.
- Improved prompt vault duplicate handling and local-save feedback.
- Added request timeouts and a more reliable image download path with browser-open fallback.
- Synced Android WebView asset with the current web UI.
