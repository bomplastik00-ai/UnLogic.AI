
# unlogic.ai — Multi-Engine Starter

Ini ialah **starter project**, bukan APK siap dan bukan sistem AI yang sudah mempunyai kredit/API.
Ia menyediakan asas UI, satu backend pintu masuk, konfigurasi penyedia, dan projek Android WebView untuk dibina melalui cloud.

## Apa yang sudah ada
- UI responsif dengan enam modul: Create Image, Smart Edit, Simple Edit, Video AI, Effects AI, Character Swap.
- Template/preset prompt asas dan Prompt Vault menggunakan `localStorage`.
- Satu endpoint backend `/api/generate`.
- Gateway multi-engine: senarai penyedia boleh dikonfigurasi melalui secret `PROVIDERS_JSON`; adapter imej untuk API OpenAI-compatible dan adapter queue fal.ai (submit + polling status/result) bagi model yang disokong.
- API key hanya dibaca di backend melalui secret `PROVIDERS_JSON`.
- Sokongan job asynchronous asas untuk fal.ai; browser hanya menerima ID job, bukan API key.
- Android WebView wrapper yang memuatkan UI daripada `app/src/main/assets/index.html`.
- GitHub Actions workflow untuk build APK debug.

## Apa yang BELUM siap
- Tiada API key atau kredit AI disertakan.
- Smart Edit, Simple Edit, Video AI, Effects AI dan Character Swap belum disambungkan kepada enjin sebenar.
- Belum diuji pada peranti sebenar dan belum ada APK yang dibina.
- Penyedia AI mempunyai format API, harga, had dan polisi kandungan yang berbeza. Jangan anggap satu API serasi dengan semua penyedia.

## Susunan folder
- `web/index.html` — UI web.
- `worker/src/index.ts` — backend Cloudflare Worker.
- `worker/wrangler.toml` — konfigurasi Worker.
- `ENGINE_RESEARCH_MS.md` — shortlist penyedia, harga dan pautan dokumentasi rasmi.
- `android/` — projek Android WebView.
- `.github/workflows/android-apk.yml` — bina APK debug dalam GitHub Actions.

## Ujian UI tanpa akaun
Buka `web/index.html` dalam browser. UI akan terbuka, tetapi Generate memerlukan backend yang telah dikonfigurasi.

## Backend — konfigurasi
1. Deploy folder `worker` sebagai Cloudflare Worker menggunakan Wrangler / dashboard.
2. Set Worker secret `PROVIDERS_JSON` menggunakan struktur dalam `worker/PROVIDERS_JSON.example.json`. Gantikan `baseUrl`, `apiKey`, `model` dan `endpoint` dengan nilai sebenar daripada dokumentasi penyedia. Anda boleh menyenaraikan beberapa enjin dalam satu JSON object.
   - Set `APP_ORIGINS` kepada origin yang tepat, termasuk `https://appassets.androidplatform.net` untuk Android WebView.
   - `ALLOW_ADULT_MODE` kekal `false` sehingga semakan polisi dan perlindungan berkaitan dibuat.
3. Set variable `ALLOW_ADULT_MODE` kepada `false` secara lalai. Hanya hidupkan jika penyedia yang dipilih secara jelas membenarkan kandungan dewasa sah dan sistem umur/persetujuan yang diperlukan telah disediakan.
4. Set `APP_ORIGINS` kepada senarai origin yang tepat dan dibenarkan. Jangan kosongkan atau gunakan wildcard pada production.

**Nota:** Setiap penyedia perlu disemak dokumentasi semasanya. Ada penyedia yang tidak menyokong `images/generations`, parameter `size`, atau format respons yang sama. Jika begitu, adapter perlu ditulis khusus untuk penyedia tersebut.

## Android APK
Projek Android menggunakan WebView yang memuatkan UI daripada assets. Ia boleh dibina melalui GitHub Actions selepas projek dimasukkan ke repositori GitHub. Build workflow menghasilkan APK debug sebagai artifact. APK ini masih memerlukan backend yang telah dideploy untuk menjana imej.

## Keselamatan
- Jangan masukkan API key dalam HTML, JavaScript browser, Android assets, atau APK.
- Gunakan HTTPS.
- Hadkan CORS, saiz permintaan, kadar penggunaan dan perbelanjaan API.
- Tambah login/quota/rate limiting sebelum aplikasi dibuka kepada orang ramai.
- Jangan gunakan sistem ini untuk kandungan seksual bawah umur atau imej intim tanpa persetujuan.

## Adapter fal.ai (contoh Create Image)

`worker/PROVIDERS_JSON.example.json` kini mempunyai contoh `fal_z_image_turbo`. Model `fal-ai/z-image/turbo` menggunakan API queue fal.ai dan adapter ini menghantar prompt, kemudian polling status sehingga imej siap. Harga dan model boleh berubah; semak halaman model sebelum guna. Jangan anggap percuma.

Untuk fal.ai, `PROVIDERS_JSON` mesti disimpan sebagai Worker secret. `apiKey` guna fal API key. UI memerlukan backend URL dan provider yang muncul dalam senarai.

## Penambahan v0.4
Versi ini menambah butang **Test connection**, status backend, bilangan engine yang dikonfigurasi dan butang **Reload engines**. Maklumat status tidak mendedahkan API key. Modul selain Create Image kini ditandakan Coming soon dan butang jana dinyahaktifkan supaya tidak memberi gambaran palsu bahawa adapter sudah berfungsi. Prompt Vault mengelakkan prompt pendua dan output imej boleh dimuat turun dengan fallback membuka imej di tab/paparan baharu.

**Status sebenar:** v0.4 masih starter build. Create Image mempunyai adapter backend untuk fal.ai queue dan OpenAI-compatible image API. Modul Smart Edit, Simple Edit, Video AI, Effects AI dan Character Swap belum mempunyai adapter AI. Ujian sintaks dan struktur bukan bukti bahawa API provider sebenar telah berjaya digunakan.
