# unlogic.ai — senarai ujian milestone 0.2

## UI sahaja
- [ ] Buka `web/index.html` dalam browser.
- [ ] Tukar antara enam modul; UI tidak crash.
- [ ] Pilih preset dan pastikan prompt terisi.
- [ ] Simpan prompt dan reload; Prompt Vault masih ada.
- [ ] Masukkan Backend URL dan pastikan ia tersimpan selepas reload.

## Backend sebelum AI
- [ ] `GET /api/health` pulangkan `ok: true`.
- [ ] `GET /api/providers` hanya pulangkan ID, label dan capability, bukan API key.
- [ ] Origin yang tidak disenaraikan dalam `APP_ORIGINS` ditolak.
- [ ] Tanpa `PROVIDERS_JSON`, `/api/generate` pulangkan mesej konfigurasi yang jelas.
- [ ] Prompt kosong ditolak.
- [ ] Adult mode ditolak secara lalai.

## Create Image dengan provider sebenar
- [ ] Guna provider yang dokumentasinya mengesahkan endpoint dan format request.
- [ ] Satu provider dipaparkan dalam dropdown.
- [ ] Prompt ujian menghasilkan imej.
- [ ] Imej boleh dipaparkan dan dimuat turun.
- [ ] API key tidak muncul dalam browser DevTools, APK atau response.
- [ ] Uji kredit habis, model salah dan timeout; mesej ralat tidak mendedahkan rahsia.

## Android
- [ ] Build `assembleDebug` berjaya di GitHub Actions.
- [ ] Pasang APK pada Android sebenar.
- [ ] WebView memaparkan UI.
- [ ] Tetapan backend dan Prompt Vault kekal selepas aplikasi ditutup dan dibuka semula.
- [ ] Android WebView boleh memanggil backend dengan origin `https://appassets.androidplatform.net`.

## Had milestone ini
- Backend belum ada akaun pengguna, billing, kuota, database, penyimpanan output kekal atau rate limiting.
- Adapter imej hanya menyokong API yang serasi dengan format OpenAI Images. Provider lain memerlukan adapter khusus.
- Lima modul selain Create Image belum disambungkan kepada AI sebenar.
- APK belum dibina atau diuji dalam persekitaran ini.


## fal.ai queue adapter v0.3
- [ ] Tambah fal API key ke `PROVIDERS_JSON` sebagai Worker secret.
- [ ] Semak model ID dan schema semasa pada halaman fal model.
- [ ] `GET /api/providers` memaparkan fal engine tanpa mendedahkan API key.
- [ ] Generate memulangkan job ID dan UI memaparkan status menunggu.
- [ ] Polling status selesai dan result image URL dipaparkan.
- [ ] Uji API key salah, kredit tidak mencukupi, timeout dan job gagal.
- [ ] Pastikan key tidak muncul dalam response browser atau APK.
