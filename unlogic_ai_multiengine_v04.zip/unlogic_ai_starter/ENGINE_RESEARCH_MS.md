# Kajian penyedia enjin AI — unlogic.ai

Dokumen ini ialah shortlist awal berdasarkan dokumentasi rasmi yang disemak pada 14 November 2026. Harga, model dan polisi boleh berubah; semak semula sebelum masukkan API key atau membuat bayaran.

## 1. fal.ai — calon untuk imej dan video

- Satu API key menyediakan akses kepada banyak model imej, video dan media.
- API menyokong mod queue: hantar job, terima `request_id`, semak status dan ambil hasil. Ini sesuai untuk tugas video yang lama.
- Dokumentasi rasmi: https://fal.ai/docs/api-reference/inference-api/queue/submit
- Contoh model imej Z-Image Turbo: https://fal.ai/models/fal-ai/z-image/turbo/api
- Harga rasmi: https://fal.ai/pricing
- Harga dibayar mengikut output/model. Contoh harga pada halaman model/pricing boleh berubah; jangan anggap percuma atau membuat andaian jumlah kos sebelum semak halaman harga.
- Adapter fal.ai queue untuk contoh Z-Image Turbo sudah dimasukkan dalam v0.3, tetapi belum diuji dengan API key sebenar.

## 2. Hugging Face Inference Providers — pilihan eksperimen kos rendah

- Dokumentasi semasa menyatakan akaun Free menerima kredit bulanan USD 0.10, tertakluk perubahan. Nilai ini sangat kecil dan hanya sesuai untuk percubaan ringkas, bukan penggunaan harian berat.
- Akses kepada pelbagai provider/model; format API berbeza mengikut provider dan model. Jangan anggap semua model menggunakan endpoint imej yang sama.
- Dokumentasi rasmi: https://huggingface.co/docs/inference-providers/pricing
- Belum ada adapter khusus Hugging Face dalam v0.3.

## 3. Cloudflare Workers AI — backend dan pilihan model tertentu

- Workers AI menyediakan kuota percuma harian 10,000 Neurons menurut halaman harga yang dikemas kini pada 12 November 2026; penggunaan melebihi kuota pada pelan Paid dikenakan caj. Model tertentu memerlukan kaedah bayaran.
- Dokumentasi rasmi: https://developers.cloudflare.com/workers-ai/platform/pricing/
- Cloudflare Workers sesuai sebagai backend/gateway, tetapi ia bukan katalog universal yang menjamin semua fungsi imej/video atau kandungan dewasa. Semak katalog model dan polisi setiap model.

## Cadangan untuk projek

1. Kekalkan Cloudflare Worker sebagai gateway sahaja; jangan cuba jadikan ia model AI.
2. Uji satu model imej melalui fal.ai queue adapter atau provider yang mempunyai format API jelas.
3. Untuk percubaan tanpa kos, semak kredit Hugging Face tetapi anggap kuotanya terlalu kecil untuk ujian banyak imej.
4. Video, effects dan character swap perlu adapter serta aliran job khusus; jangan gunakan satu endpoint imej untuk semua modul.
5. Adult mode kekal OFF. Setiap penyedia/model mesti dinilai berdasarkan polisi kandungan dan perlindungan umur/persetujuan. Tiada jaminan penyedia yang disenaraikan membenarkan kandungan dewasa eksplisit.
